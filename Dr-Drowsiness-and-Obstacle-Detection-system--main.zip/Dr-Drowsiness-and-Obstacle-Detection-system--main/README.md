# Dr-Drowsiness-and-Obstacle-Detection-system-
The Morse Code Signalling project demonstrates a simple communication system using dots and dashes to represent letters, numbers, and symbols. Text input is converted into Morse code, which is transmitted using LEDs or buzzers as signals. At the receiving end, these signals can be decoded back into readable text and displayed on an LCD or monitor. 
